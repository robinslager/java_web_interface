package Commands.CommandExecutor.Issue;

import Commands.GetIssue;

public class GetIssue_All_CurrentRepo extends GetIssue {
    public GetIssue_All_CurrentRepo() {


    }
}
