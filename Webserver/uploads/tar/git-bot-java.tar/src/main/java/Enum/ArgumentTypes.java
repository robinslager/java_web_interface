package Enum;

public enum ArgumentTypes {
    NONE,
    STRING,
    INTEGER,
    All
}
