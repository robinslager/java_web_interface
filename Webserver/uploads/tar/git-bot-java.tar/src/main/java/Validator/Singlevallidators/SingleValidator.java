package Validator.Singlevallidators;

public abstract class SingleValidator {

    /**
     * function will validate a part of command needs this for validation
     * @return Boolean
     */
    public abstract boolean validate();
}
